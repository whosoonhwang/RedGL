"use strict";
var RedAtlasTextureInfo;
(function () {
	var tGL;
	var MAX_TEXTURE_SIZE;
	var tAtlas; // 대상 아틀라스
	var atlasIntanceList; // 아틀라스 객체 리스트
	var atlasKeyMap; // 아틀라스에 등록된 이미지 맵정보
	var createAtlas; // 아틀라스 캔버스 생성기
	var atlasPack; // 아틀라스에 이미지를 실제로 업로드하는 녀석
	createAtlas = function (targetImage) {
		var canvas;
		var t0;
		if (targetImage && (targetImage['width'] > MAX_TEXTURE_SIZE || targetImage['height'] > MAX_TEXTURE_SIZE)) throw '이미지가 너무커!'
		canvas = document.createElement('canvas');
		canvas.width = MAX_TEXTURE_SIZE, canvas.height = MAX_TEXTURE_SIZE;
		canvas.style.background = 'red', canvas.style.margin = '3px', canvas.style.display = 'inline-block'
		document.body.appendChild(canvas)
		// 아틀라스 생성
		tAtlas = new Atlas(canvas);
		atlasIntanceList.push(tAtlas)
	}
	atlasPack = function (targetImage) {
		tAtlas = atlasIntanceList[0]
		var node = tAtlas.pack(targetImage);
		var i, len;
		if (node === false) {
			// 아틀라스를 전체를 돌면서 찾아야하고..
			i = 0, len = atlasIntanceList.length
			for (i; i < len; i++) {
				// 기존있는놈중에 들어가면 종료시키고
				tAtlas = atlasIntanceList[i]
				node = tAtlas.pack(targetImage);
				if (node) return
			}
			// 여기까지 흘러들어오면 아틀라스캔버스 자체를 추가한다.
			if (node === false) {
				createAtlas(targetImage)
				node = tAtlas.pack(targetImage)
			}
		}
		return node
	}
	atlasKeyMap = {}
	atlasIntanceList = []

	/**DOC:
		{
			constructorYn : true,
			title :`RedAtlasTextureInfo`,
			description : `
				- Atlas 텍스쳐 생성기
			`,
			params : {
				redGL : [
					{type:'RedGL Instance'}
				]
			},
			example : `
				TODO:
			`,
			return : 'RedAtlasTextureInfo Instance'
		}
	:DOC*/
	RedAtlasTextureInfo = function (redGL, srcList) {
		if (!(this instanceof RedAtlasTextureInfo)) return new RedAtlasTextureInfo(redGL, srcList)
		if (!(redGL instanceof RedGL)) throw 'RedGL 인스턴스만 허용됩니다.'
		if (!(srcList instanceof Array)) srcList = [srcList]
		// 이놈이 아틀라스 사이즈가 된다.
		MAX_TEXTURE_SIZE = redGL['detect']['MAX_TEXTURE_SIZE']
		if (!tAtlas) createAtlas()
		var i, len;
		i = 0, len = srcList.length
		for (i; i < len; i++) {
			var img = new Image();
			var id = 'atlasImage_' + srcList[i]
			if (atlasKeyMap[id]) return
			img.id = id
			img.src = srcList[i]
			atlasKeyMap[id] = 1 //  존재하는지 여부만 입력함
			img.onload = function () {
				var node = atlasPack(this)
				console.log(node)
				console.log(tAtlas.uv()[node.rect['name']])
			};
		}
	}
})();